package com.example.wieghttrackingapp_kendallferebee;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SmsPermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1001;

    // Register the activity result launcher for permission request
    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    // Permission is granted, send SMS notification
                    sendSmsNotification();
                } else {
                    // Permission denied, show rationale or continue without SMS feature
                    showPermissionRationale();
                }
            });

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sms_permission);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Check if SMS permission is granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            // Permission already granted, send SMS notification
            sendSmsNotification();
        } else {
            // Request SMS permission
            requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    private void sendSmsNotification() {
        String phoneNumber = "1234567890"; // Replace with the actual phone number
        String message = "You have reached your goal weight! Congratulations!";

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                PendingIntent sentIntent = PendingIntent.getBroadcast(this, 0, new Intent("SMS_SENT"), PendingIntent.FLAG_IMMUTABLE);
                smsManager.sendTextMessage(phoneNumber, null, message, sentIntent, null);
                Toast.makeText(this, "SMS sent successfully!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Failed to send SMS.", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "SMS permission not granted", Toast.LENGTH_SHORT).show();
        }
    }

    private void showPermissionRationale() {
        // Show a rationale to the user, explaining why the permission is needed
        new AlertDialog.Builder(this)
                .setTitle("SMS Permission Needed")
                .setMessage("This app needs SMS permission to send notifications when you reach your goal weight.")
                .setPositiveButton("Grant Permission", (dialog, which) -> {
                    // Re-request the permission
                    requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
                })
                .setNegativeButton("Cancel", (dialog, which) -> {
                    // User declined the permission, continue without SMS feature
                    Toast.makeText(this, "SMS permission denied. The app will continue without SMS notifications.", Toast.LENGTH_SHORT).show();
                })
                .show();
    }
}
