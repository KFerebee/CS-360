package com.example.wieghttrackingapp_kendallferebee;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.SimpleCursorAdapter;

import androidx.appcompat.app.AppCompatActivity;

public class DataDisplayActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;  // Database helper for managing SQLite operations
    private GridView gridView;  // GridView for displaying database entries
    private EditText dateEditText, weightEditText;  // Input fields for date and weight
    private SimpleCursorAdapter adapter;  // Adapter for binding database data to the GridView

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        // Initialize the database helper and UI elements
        dbHelper = new DatabaseHelper(this);
        gridView = findViewById(R.id.data_grid);
        dateEditText = findViewById(R.id.dateEditText);
        weightEditText = findViewById(R.id.weightEditText);
        Button addButton = findViewById(R.id.addButton);

        // Display the current contents of the database in the GridView
        displayDatabaseContents();

        // Add button click listener to add a new weight entry
        addButton.setOnClickListener(v -> addWeightEntry());

        // Long click listener for GridView items to confirm and delete an entry
        gridView.setOnItemLongClickListener((parent, view, position, id) -> {
            confirmDeletion(id);  // Prompt the user to confirm deletion
            return true;  // Return true to indicate the event is handled
        });
    }

    // Method to display the contents of the database in the GridView
    private void displayDatabaseContents() {
        Cursor cursor = dbHelper.getAllWeightEntries();  // Get all weight entries from the database
        String[] from = new String[]{DatabaseHelper.COLUMN_DATE, DatabaseHelper.COLUMN_WEIGHT};  // Columns to display
        int[] to = new int[]{R.id.dateTextView, R.id.weightTextView};  // TextViews to bind data to

        // Set up the adapter with the cursor and column mappings
        adapter = new SimpleCursorAdapter(this, R.layout.grid_item, cursor, from, to, 0);
        gridView.setAdapter(adapter);  // Set the adapter to the GridView
    }

    // Method to add a new weight entry to the database
    private void addWeightEntry() {
        String date = dateEditText.getText().toString().trim();  // Get the date input
        String weightStr = weightEditText.getText().toString().trim();  // Get the weight input

        // Check if either date or weight is empty
        if (date.isEmpty() || weightStr.isEmpty()) {
            android.widget.Toast.makeText(this, "Please enter both date and weight", android.widget.Toast.LENGTH_SHORT).show();
            return;  // Exit the method if inputs are invalid
        }

        try {
            int weight = Integer.parseInt(weightStr);  // Parse the weight input to an integer
            dbHelper.addWeightEntry(date, weight);  // Add the new entry to the database
            refreshData();  // Refresh the GridView to show the updated data
            clearInputFields();  // Clear the input fields after adding the entry
            android.widget.Toast.makeText(this, "Entry added successfully", android.widget.Toast.LENGTH_SHORT).show();
        } catch (NumberFormatException e) {
            android.widget.Toast.makeText(this, "Please enter a valid number for weight", android.widget.Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            android.widget.Toast.makeText(this, "Error adding entry: " + e.getMessage(), android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    // Method to prompt the user for deletion confirmation
    private void confirmDeletion(long id) {
        new AlertDialog.Builder(this)
                .setTitle("Confirm Deletion")  // Set the dialog title
                .setMessage("Are you sure you want to delete this entry?")  // Set the dialog message
                .setPositiveButton("Yes", (dialog, which) -> deleteWeightEntry(id))  // If "Yes" is clicked, delete the entry
                .setNegativeButton("No", null)  // If "No" is clicked, dismiss the dialog
                .show();  // Show the dialog
    }

    // Method to delete a weight entry from the database
    private void deleteWeightEntry(long id) {
        dbHelper.deleteWeightEntry((int) id);  // Delete the entry with the specified ID
        refreshData();  // Refresh the GridView to show the updated data
        android.widget.Toast.makeText(this, "Entry deleted successfully", android.widget.Toast.LENGTH_SHORT).show();
    }

    // Method to refresh the GridView with updated data
    private void refreshData() {
        Cursor newCursor = dbHelper.getAllWeightEntries();  // Get the updated list of entries
        adapter.changeCursor(newCursor);  // Update the adapter's cursor
        adapter.notifyDataSetChanged();  // Notify the adapter that the data has changed
    }

    // Method to clear the input fields after adding or editing an entry
    private void clearInputFields() {
        dateEditText.setText("");  // Clear the date input field
        weightEditText.setText("");  // Clear the weight input field
    }

    // Database Helper class to manage SQLite operations
    public static class DatabaseHelper extends SQLiteOpenHelper {

        private static final String DATABASE_NAME = "weight_tracking.db";  // Database name
        private static final int DATABASE_VERSION = 1;  // Database version

        // Table and column names for weight entries
        private static final String TABLE_WEIGHT = "daily_weight";
        private static final String COLUMN_ID = "_id";
        private static final String COLUMN_DATE = "date";
        private static final String COLUMN_WEIGHT = "weight";

        // Table and column names for users
        private static final String TABLE_USERS = "users";
        private static final String COLUMN_USER_ID = "id";
        private static final String COLUMN_USERNAME = "username";
        private static final String COLUMN_PASSWORD = "password";

        DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);  // Initialize the database helper
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            // Create the weight tracking table
            String createWeightTable = "CREATE TABLE " + TABLE_WEIGHT + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_DATE + " TEXT, " +
                    COLUMN_WEIGHT + " INTEGER)";
            db.execSQL(createWeightTable);  // Execute the SQL statement

            // Create the users table (for login functionality, etc.)
            String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                    COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_USERNAME + " TEXT UNIQUE, " +
                    COLUMN_PASSWORD + " TEXT)";
            db.execSQL(createUsersTable);  // Execute the SQL statement
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // Drop existing tables if they exist and recreate them
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHT);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
            onCreate(db);  // Recreate the tables
        }

        // Method to get all weight entries from the database
        Cursor getAllWeightEntries() {
            SQLiteDatabase db = this.getReadableDatabase();  // Get readable database
            return db.query(TABLE_WEIGHT, null, null, null, null, null, COLUMN_DATE + " ASC");  // Query the database
        }

        // Method to add a new weight entry to the database
        public void addWeightEntry(String date, int weight) {
            SQLiteDatabase db = this.getWritableDatabase();  // Get writable database
            ContentValues values = new ContentValues();  // Create ContentValues to hold data
            values.put(COLUMN_DATE, date);  // Add date to ContentValues
            values.put(COLUMN_WEIGHT, weight);  // Add weight to ContentValues
            db.insert(TABLE_WEIGHT, null, values);  // Insert the new entry into the database
            db.close();  // Close the database connection
        }

        // Method to delete a weight entry from the database
        public void deleteWeightEntry(int id) {
            SQLiteDatabase db = this.getWritableDatabase();  // Get writable database
            db.delete(TABLE_WEIGHT, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});  // Delete the entry with the specified ID
            db.close();  // Close the database connection
        }

        // Method to add a new user to the database
        public boolean addUser(String username, String password) {
            SQLiteDatabase db = this.getWritableDatabase();  // Get writable database
            ContentValues values = new ContentValues();  // Create ContentValues to hold data
            values.put(COLUMN_USERNAME, username);  // Add username to ContentValues
            values.put(COLUMN_PASSWORD, password);  // Add password to ContentValues

            // Try to insert the new user and check for success
            long result = db.insert(TABLE_USERS, null, values);
            db.close();  // Close the database connection
            return result != -1;  // Return true if the insertion was successful
        }

        // Method to check if a user exists with the given username and password
        public boolean checkUser(String username, String password) {
            SQLiteDatabase db = this.getReadableDatabase();  // Get readable database
            String[] columns = {COLUMN_USER_ID};  // Columns to return
            String selection = COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?";  // Selection criteria
            String[] selectionArgs = {username, password};  // Selection arguments

            Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
            int count = cursor.getCount();  // Get the number of matching rows
            cursor.close();  // Close the cursor
            db.close();  // Close the database connection

            return count > 0;  // Return true if at least one match was found
        }
    }
}
